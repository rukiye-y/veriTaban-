﻿namespace hayvanatBahçesi
{
    partial class ziyaret
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.zYasT = new System.Windows.Forms.TextBox();
            this.zYas = new System.Windows.Forms.Label();
            this.zAd = new System.Windows.Forms.TextBox();
            this.zAdl = new System.Windows.Forms.Label();
            this.bZGüncel = new System.Windows.Forms.Button();
            this.bZAra = new System.Windows.Forms.Button();
            this.bZSil = new System.Windows.Forms.Button();
            this.bZEkle = new System.Windows.Forms.Button();
            this.dataGridView2 = new System.Windows.Forms.DataGridView();
            this.zidt = new System.Windows.Forms.TextBox();
            this.zid = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).BeginInit();
            this.SuspendLayout();
            // 
            // zYasT
            // 
            this.zYasT.Location = new System.Drawing.Point(554, 73);
            this.zYasT.Name = "zYasT";
            this.zYasT.Size = new System.Drawing.Size(100, 22);
            this.zYasT.TabIndex = 20;
            // 
            // zYas
            // 
            this.zYas.AutoSize = true;
            this.zYas.Location = new System.Drawing.Point(477, 79);
            this.zYas.Name = "zYas";
            this.zYas.Size = new System.Drawing.Size(81, 16);
            this.zYas.TabIndex = 19;
            this.zYas.Text = "ziyaretçi yas";
            // 
            // zAd
            // 
            this.zAd.Location = new System.Drawing.Point(554, 45);
            this.zAd.Name = "zAd";
            this.zAd.Size = new System.Drawing.Size(100, 22);
            this.zAd.TabIndex = 18;
            // 
            // zAdl
            // 
            this.zAdl.AutoSize = true;
            this.zAdl.Location = new System.Drawing.Point(477, 48);
            this.zAdl.Name = "zAdl";
            this.zAdl.Size = new System.Drawing.Size(79, 16);
            this.zAdl.TabIndex = 17;
            this.zAdl.Text = "ziyaretçi Adı";
            this.zAdl.Click += new System.EventHandler(this.hAdl_Click);
            // 
            // bZGüncel
            // 
            this.bZGüncel.Location = new System.Drawing.Point(554, 239);
            this.bZGüncel.Name = "bZGüncel";
            this.bZGüncel.Size = new System.Drawing.Size(75, 23);
            this.bZGüncel.TabIndex = 16;
            this.bZGüncel.Text = "Güncelle";
            this.bZGüncel.UseVisualStyleBackColor = true;
            // 
            // bZAra
            // 
            this.bZAra.Location = new System.Drawing.Point(554, 207);
            this.bZAra.Name = "bZAra";
            this.bZAra.Size = new System.Drawing.Size(75, 23);
            this.bZAra.TabIndex = 15;
            this.bZAra.Text = "arama";
            this.bZAra.UseVisualStyleBackColor = true;
            // 
            // bZSil
            // 
            this.bZSil.Location = new System.Drawing.Point(554, 178);
            this.bZSil.Name = "bZSil";
            this.bZSil.Size = new System.Drawing.Size(75, 23);
            this.bZSil.TabIndex = 14;
            this.bZSil.Text = "sil";
            this.bZSil.UseVisualStyleBackColor = true;
            // 
            // bZEkle
            // 
            this.bZEkle.Location = new System.Drawing.Point(554, 143);
            this.bZEkle.Name = "bZEkle";
            this.bZEkle.Size = new System.Drawing.Size(75, 29);
            this.bZEkle.TabIndex = 13;
            this.bZEkle.Text = "ekle";
            this.bZEkle.UseVisualStyleBackColor = true;
            // 
            // dataGridView2
            // 
            this.dataGridView2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView2.Location = new System.Drawing.Point(12, 12);
            this.dataGridView2.Name = "dataGridView2";
            this.dataGridView2.RowHeadersWidth = 51;
            this.dataGridView2.RowTemplate.Height = 24;
            this.dataGridView2.Size = new System.Drawing.Size(419, 250);
            this.dataGridView2.TabIndex = 12;
            // 
            // zidt
            // 
            this.zidt.Location = new System.Drawing.Point(554, 17);
            this.zidt.Name = "zidt";
            this.zidt.Size = new System.Drawing.Size(100, 22);
            this.zidt.TabIndex = 22;
            // 
            // zid
            // 
            this.zid.AutoSize = true;
            this.zid.Location = new System.Drawing.Point(477, 20);
            this.zid.Name = "zid";
            this.zid.Size = new System.Drawing.Size(70, 16);
            this.zid.TabIndex = 21;
            this.zid.Text = "ziyaretçi id";
            // 
            // ziyaret
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.zidt);
            this.Controls.Add(this.zid);
            this.Controls.Add(this.zYasT);
            this.Controls.Add(this.zYas);
            this.Controls.Add(this.zAd);
            this.Controls.Add(this.zAdl);
            this.Controls.Add(this.bZGüncel);
            this.Controls.Add(this.bZAra);
            this.Controls.Add(this.bZSil);
            this.Controls.Add(this.bZEkle);
            this.Controls.Add(this.dataGridView2);
            this.Name = "ziyaret";
            this.Text = "ziyaretçi";
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.TextBox zYasT;
        private System.Windows.Forms.Label zYas;
        private System.Windows.Forms.TextBox zAd;
        private System.Windows.Forms.Label zAdl;
        private System.Windows.Forms.Button bZGüncel;
        private System.Windows.Forms.Button bZAra;
        private System.Windows.Forms.Button bZSil;
        private System.Windows.Forms.Button bZEkle;
        private System.Windows.Forms.DataGridView dataGridView2;
        private System.Windows.Forms.TextBox zidt;
        private System.Windows.Forms.Label zid;
    }
}